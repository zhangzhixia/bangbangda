$(function(){
	var iW=window.innerWidth;
	var iH=window.innerHeight;
	var vertic1H=parseInt($('#verticScrollArea').css('height'));//获取第一竖屏的总高度
	var horizontalContainer=document.getElementById('horizontalScrollArea');
	var horizonDivs= horizontalContainer.children ;
	//第2屏
	
	$(horizonDivs).each(function(i,elem){
		$(elem).css({
			width:iW,
			height:iH,
			overflow:'hidden',
			position:'absolute',
			top:0,
			bottom:0,
			// left:iW*i,
			textAlign:'center',
			marginLeft:'auto',
			display: 'block'
		})
	})
	$(horizontalContainer).css({
		width:horizonDivs.length*iW,
		height:iH,
		left:0
	})
	$('#section6_0').css({
		left:0,
		zIndex:40,
	})
	$('#section6').css({
		left:iW,
		zIndex:60
	})
	$('#section7').css({
		left:iW,
		zIndex:56
	})
	$('#shuffle3').css({
		left:iW,
		zIndex:50
	})
	$('#section8').css({
		left:iW,
		zIndex:60
	})
	$('#section9').css({
		left:iW,
		zIndex:56
	})
	$('#section10').css({
		left:iW,
		zIndex:54
	})
	$('#shuffle4').css({
		left:iW,
		zIndex:53
	})
	$('#section11').css({
		left:iW,
		zIndex:54
	})
	$('#section11bis').css({
		left:iW,
		zIndex:54
	})
	$('#shuffle5').css({
		left:iW,
		zIndex:53
	})
	$('#section12').css({
		left:iW,
		zIndex:54
	})
	$('#section13').css({
		left:iW,
		zIndex:54
	})
	$('#shuffle6').css({
		left:iW,
		zIndex:53
	})
	//生成枪战的所有图片
	// var str='';
	// for(var i=2;i<25;i++){
	// 	str+='<img src="../img/10/'+i+'.jpg"/>';
	// }
	// $('#section10_content').append(str);
	// var sec10s=$('#section10_content')[0].children;
	// var sec10H=iH*sec10s.length;
	// $('#section10').css({
	// 	height:sec10H,
	// 	top:0
	// })
	// $('#section10_content').css({
	// 	position:'relative',
	// 	height:sec10H,
	// 	left:0,
	// 	top:0
	// });
	// $(sec10s).each(function(i,elem){
	// 	$(elem).css({
	// 		position:'absolute',
	// 		top:0,
	// 		left:0,
	// 		zIndex:i
	// 	})
	// })


	//第3平的left值是：第二横屏的宽度
	//bottom：第二横屏的高度
	var verticScrollArea2=document.getElementById('verticScrollArea2');
	var verticDivs2= verticScrollArea2.children ;//获取第二个竖屏的总高度
	var horizontalScrollArea=document.getElementById('horizontalScrollArea');
	var horiLen=horizontalScrollArea.children;
	var horiLeft=horizontalScrollArea.lastElementChild.offsetLeft;
	var verticH=verticDivs2.length*iH;
	var screen2W=horiLeft+iW;//第一横屏的宽度
	//第3屏
	$(verticScrollArea2).css({
		bottom:0,
		left:0,
		width:iW,
		height:verticH,
		overflow:'hidden',
		marginTop:-134
	})
	$(verticDivs2).each(function(i,elem){
		$(elem).css({
			position:'absolute',
			left:0,
			bottom:iH,
			height:iH,
			width:iW,
			textAlign:'center',
			overflow:'hidden'
		})
	})
	$('#section14').css({zIndex:30})
	$('#section15').css({zIndex:28})
	$('#shuffle7').css({zIndex:26,bottom:iH})
	

	var horizontalScroll2=document.getElementById('horizontalScroll2');
	var horizontalScrollArea2=document.getElementById('horizontalScrollArea2');
	var horizon2s= horizontalScrollArea2.children ;
	//第4屏
	$(horizon2s).each(function(i,elem){
		$(elem).css({
			position:'absolute',
			left:0,
			top:0,
			bottom:iH,
			height:iH,
			width:iW,
			textAlign:'center',
			overflow:'hidden'
		})
	})
	$(horizontalScroll2).css({
		width:iW,
		left:iW,
		height:iH,
	})
//重置第4屏的布局样式
	$('#section16').css({zIndex:30})
	$('#section17').css({zIndex:30})
	$('#section18').css({zIndex:28})
	$('#shuffle8').css({zIndex:26})
	$('#section19').css({zIndex:28,top:iH})
	$('#final').css({zIndex:28,top:iH})

//设置大滚动条
var track=document.querySelector('#scrollBar .track')//滚动条
var bjTrack=document.querySelector('#scrollBar .bj_track')//滚轮
var main=document.getElementById('main');
var horizontalScrollArea=document.getElementById('horizontalScrollArea');
var vertic1H=parseInt($('#verticScrollArea').css('height'));
var disY=0;
var Scale1=0;
var cale2=0;
var Scale3=0;
var Scale4=0;
var Scale5=0;
//鼠标拖动滚轮触发
// bjTrack.addEventListener('mousedown',fnDown);
function fnDown(ev){
	disY=ev.pageY-bjTrack.offsetTop;
	document.addEventListener('mousemove',FnMove);
	document.addEventListener('mouseup',FnUp);
	function FnMove(ev){
		var pgT=ev.pageY-disY;
		if(pgT<=0){
			pgT=0;
		}else if(pgT>=track.offsetHeight-bjTrack.offsetHeight){
			pgT=track.offsetHeight-bjTrack.offsetHeight;
		}
		$(bjTrack).css('top',pgT+'px');
		bjTrack.style.top=pgT+'px';
		//滚动第一屏
		if(bjTrack.offsetTop<=108){
			Scale1=bjTrack.offsetTop/108;
			main.style.top=vertic1H*-Scale1+'px';

		}else if(bjTrack.offsetTop>108 && bjTrack.offsetTop<=390){
			Scale2=(bjTrack.offsetTop-130)/260;
			horizontalContainer.style.left=-screen2W*Scale2+'px';
		}
	}
	function FnUp(){
		document.removeEventListener('mousemove',FnMove);
		document.removeEventListener('mouseup',FnUp);
	}
}
var horiTop=horizontalScrollArea.lastElementChild.offsetTop;
var container=document.getElementById('container');
var oImg=document.getElementById('img');
var num=1;
var onOff=true;
fnGun(container,function(down){
	var T=bjTrack.offsetTop;
	var horizL=parseInt($('#horizontalScrollArea').css('left'));
	// console.log(horizL)
	//向上滚
	if(down){
		T-=1;
		if(T<=0){
			T=0
		}
		var timerO=setTimeout(function(){
			$('#section1_scroll').animate({opacity:100},100);
			$('#section1_arrow').animate({marginTop:'546px',opacity:100},80);
			$('#section1_better').animate({bottom:'20px',opacity:100},120);
			$('#shuffle1_zev').animate({opacity:100},50);
			$('#shuffle2_sport').animate({opacity:100},50);
			$('#shuffle3_4wd').animate({opacity:100},50);
			$('#shuffle4_auto').animate({opacity:100},50);
			$('#shuffle5_4wd2').animate({opacity:100},50);
			$('#shuffle6_zev2').animate({opacity:100},50);
			$('#shuffle7_auto2').animate({opacity:100},50);
			$('#shuffle8_zev3').animate({opacity:100},50);
		},100)
		twoScreen(bjTrack.offsetTop);
		//枪战动画
		if(bjTrack.offsetTop>=258&&bjTrack.offsetTop<=282){
			num--;
			if(num<1){
				num=1;
			}
			oImg.src='../img/10/'+num+'.jpg';

		}

	}else{
		T+=1;
		if(T>=track.offsetHeight-bjTrack.offsetHeight){
			T=track.offsetHeight-bjTrack.offsetHeight;
		}
		$('#section1_scroll')[0].style.opacity=0;
		var obj = {
			'element': $('#section1_arrow')[0],
			'type': "easeOut",
			'time': 800,
			'target': {'marginTop':650, 'opacity':0}
		};
		mTween(obj);
		var obj2 = {
			'element': $('#section1_better')[0],
			'type': "easeOut",
			'time': 300,
			'target': {'bottom':-30, 'opacity':0}
		};
		mTween(obj2);
		setTimeout(function(){
			$('#shuffle1_zev').animate({opacity:0},50);
			$('#shuffle2_sport').animate({opacity:0},50);
			$('#shuffle3_4wd').animate({opacity:0},50);
			$('#shuffle4_auto').animate({opacity:0},50);
			$('#shuffle5_4wd2').animate({opacity:0},50);
			$('#shuffle6_zev2').animate({opacity:0},50);
			$('#shuffle7_auto2').animate({opacity:0},50);
			$('#shuffle8_zev3').animate({opacity:0},50);
		},100)
		twoScreen(bjTrack.offsetTop);
		//枪战动画
		if(bjTrack.offsetTop>=258&&bjTrack.offsetTop<=282){
			num++;
			if(num>23){
				num=23;
			}
			oImg.src='../img/10/'+num+'.jpg';

		}
	}
	//切换开关灯
	// var horizonL=parseInt($('#horizontalScrollArea2').css('left'));
	// var arr=['../img/18/bg.jpg','../img/18/bg2.jpg'];
	// if(horizonL<-3500){
	// 	$('#section18_bg')[0].src=arr[1];
	// }else{
	// 	$('#section18_bg')[0].src=arr[0];
	// }

	// $('#shuffle2')[0].style.display='block';
	$(bjTrack).css('top',T+'px');
	//第1屏
	// if(bjTrack.offsetTop>=130){
	// 	$('#shuffle2')[0].style.display='none';
	// }
	////滚动第一屏时 ，提升第一屏的层级，并将第二屏的left值恢复到0
	if(bjTrack.offsetTop>=0&&bjTrack.offsetTop<130){
		Scale1=bjTrack.offsetTop/129;
		$('#invariant')[0].style.transform='translateY('+950*-Scale1+'px)';
		$('#section_text')[0].style.transform='translateY('+335*Scale1+'px)';
		$('#section1_chair')[0].style.transform='translateY('+324*-2*Scale1+'px)';
		$('#section2_girl')[0].style.transform='translate3d('+613/2*Scale1+'px,0px,0px)';
		$('#section2_chair')[0].style.transform='translate3d('+338*Scale1+'px,0px,0px)';
		$('#section1_desk')[0].style.top=350+(2000*-Scale1)+'px';
		//碎玻璃比例（滚轮的top到滚轮移动的距离*玻璃从左到右移动的距离）
		var boli=0;
		var dogs=0;//狗吠比例
		if(bjTrack.offsetTop>=48&&bjTrack.offsetTop<=88){
			boli=(bjTrack.offsetTop-48)/40;
			$('#section3-full')[0].style.transform='translate3d('+(boli*140)+'px,0px,0px)';
		}
		if(bjTrack.offsetTop>75&&bjTrack.offsetTop<=107){
			dogs=(bjTrack.offsetTop-75)/32;
			$('#section5_dog1')[0].style.transform='translate3d('+(dogs*300)+'px,0px,0px)';
			$('#section5_dog2')[0].style.transform='translate3d('+(dogs*200)+'px,0px,0px)';
		}
		$('#verticContainer').css('zIndex',250)
		$('#horizontalScrollArea').css('left',iW+'px')
		$(main).animate({top:(vertic1H-iH)*-Scale1+"px"},50);
		// console.log(bjTrack.offsetTop)


	}else if(bjTrack.offsetTop>420 && bjTrack.offsetTop<=485){
		//第3屏
		$(verticScrollArea2).css({zIndex:400})
		var offsetTop=bjTrack.offsetTop;
		if(offsetTop>=421&&offsetTop<=440){
			var sec01=(offsetTop-421)/19;
			$('#section14').css({bottom:(iH*(1-sec01))});
		}else if(offsetTop>=441&&offsetTop<=460){
			var sec02=(offsetTop-441)/19;
			$('#section14').css({bottom:(iH*-sec02)});
			$('#section15').css({bottom:(iH*(1-sec02))});
		}else if(offsetTop>=460&& offsetTop<=485){
			var sec03=(offsetTop-459)/25;
			$('#section15').css({bottom:(iH*-sec03)});
		}
		if(offsetTop>=421&&offsetTop<=470){
			var shuf6_1=(offsetTop-421)/49;
			$('#shuffle6').css({top:(iH*shuf6_1)});
		}
		if(offsetTop>=421&&offsetTop<485){
			var shuf7=(offsetTop-421)/64;
			$('#shuffle7').css({bottom:(iH*(1-shuf7))});
			console.log(shuf7)
		}
	}else if(bjTrack.offsetTop>486 && bjTrack.offsetTop<=555){
		//第四瓶
		var offsetTop=bjTrack.offsetTop;
		if(offsetTop>=486 && offsetTop<=504){
			var shuf7=(offsetTop-486)/18;
			$('#shuffle7').css({left:300*-shuf7});
			$('#section16').css({left:iW*-shuf7});
		}else if(offsetTop>=505 && offsetTop<=524){
			var sec16=(offsetTop-505)/19;
			$('#section16').css({left:(-iW)+(iW*-sec16)});
		}
		if(offsetTop>=500 && offsetTop<=520){
			var sec17=(offsetTop-500)/20;
			$('#section17').css({left:iW*-sec17});
		}else if(offsetTop>=521 && offsetTop<=534){
			var sec17=(offsetTop-521)/13;
			$('#section17').css({left:(-iW)+(iW*-sec17)});
		}
		if(offsetTop>=513 && offsetTop<=534){
			var sec18=(offsetTop-513)/21;
			$('#section18').css({left:iW*-sec18});
			if(offsetTop>=527&& offsetTop<=530){
				var opci=(offsetTop-527)/3;
				$('#section18_bg2').css({opacity:opci})
			}
		}
	}

})
//第2屏                                                               
function twoScreen(offsetTop){
	if(offsetTop>=130 && offsetTop<=418){
		if(offsetTop>=130 && offsetTop<=135){
			var Img0=(offsetTop-130)/5;
			$('#section6_0').css({left:iW*-Img0});
		}
		//第一张图片和第二张,第三张图片一起移动
		if(offsetTop>=135&&offsetTop<=146){
			var Img1=(offsetTop-136)/10;
			$('#section6').css({left:iW*-Img1});
			$('#section7').css({left:iW*-Img1});
			$('#shuffle3').css({left:iW*-Img1});
		}else if(offsetTop>=147&&offsetTop<=174){
			var Img2=(offsetTop-147)/27;
			$('#section6').css({left:(-iW)+(iW*-Img2)});
		}else if(offsetTop>=174&&offsetTop<=201){
			var Img3=(offsetTop-175)/26;
			$('#section7').css({left:(-iW)+(iW*-Img3)});
		}
		if(offsetTop>=204&&offsetTop<=222){
			var Img5=(offsetTop-204)/18;
			$('#section8').css({left:(iW*-Img5)})
		}else if(offsetTop>=222&&offsetTop<=238){
			var Img6=(offsetTop-223)/15;
			$('#section8').css({left:(-iW)+(iW*-Img6)});
			$('#section9').css({left:(iW*-Img6)})
		}else if(offsetTop>=239&&offsetTop<=254){
			var Img8=(offsetTop-239)/15;
			$('#section9').css({left:(-iW)+(iW*-Img8)});
		}
		if(offsetTop>=202&&offsetTop<=256){
			var Img4=(offsetTop-202)/54;
			$('#shuffle3').css({left:(-iW)+(300*-Img4)})
		}
		if(offsetTop>=212 && offsetTop<=248){
			var Img7=(offsetTop-212)/36;
			$('#section10').css({left:(-iW)*Img7})
		}
		if(offsetTop>=258&&offsetTop<=268){
			var Img9=(offsetTop-258)/10;
			$('#shuffle4').css({left:(-iW*Img9)});
		}
		if(offsetTop>=283&&offsetTop<=293){
			var Img10=(offsetTop-283)/10;
			$('#section10').css({left:(-iW)+(iW*-Img10)})
		}else if(offsetTop>=294&&offsetTop<=310){
			var Img11=(offsetTop-294)/16;
			$('#section11').css({left:-iW*Img11});
		}
		if(offsetTop>=296&&offsetTop<=321){
			var ImgSh4=(offsetTop-296)/25;
			$('#shuffle4').css({left:(-iW)+(iW*-ImgSh4)});
		}
		if(offsetTop>=311&&offsetTop<=330){
			var Img12=(offsetTop-311)/19;
			$('#section11').css({left:(-iW)+(iW*-Img12)});
			$('#section11bis').css({left:-iW*Img12});
			$('#shuffle5').css({left:-iW*Img12});
		}else if(offsetTop>=331&&offsetTop<=350){
			var Img13=(offsetTop-331)/19;
			$('#section11bis').css({left:(-iW)+(iW*-Img13)});
		}else if(offsetTop>=351&&offsetTop<=370){
			var Img14=(offsetTop-351)/19;
			$('#section12').css({left:-iW*Img14});
		}else if(offsetTop>=371&&offsetTop<=395){
			var Img15=(offsetTop-371)/24;
			$('#section12').css({left:(-iW)+(iW*-Img15)});
			$('#section13').css({left:-iW*Img15});
		}else if(offsetTop>=396&&offsetTop<=415){
			var Img16=(offsetTop-396)/19;
			$('#section13').css({left:(-iW)+(iW*-Img16)});
		}
		if(offsetTop>=360&&offsetTop<=420){
			var shuf6=(offsetTop-360)/60;
			$('#shuffle6').css({left:(-iW*shuf6)});
		}

		// var treeGirl=0;//女孩和树藤图比例
		// if(offsetTop>132 && offsetTop<=157){
		// 	// $('#section7')[0].style.left=0;
		// 	treeGirl=(offsetTop-132)/25;
		// 	//400px是图片移动的幅度
		// 	$('#section6_girl')[0].style.transform='translate3d('+(-treeGirl*200)+'px,0px,0px)';
		// 	$('#shuffle2')[0].style.display='block';
		// }else if(offsetTop>=178 && offsetTop<=238){
		// 	$('#section8')[0].style.width=1394+'px';
		// 	var readyJump=(offsetTop-178)/60;
		// 	$('#section8_bg')[0].style.transform='rotate('+(-readyJump*2)+'deg)';
		// 	console.log()
		// }
		// //女孩在车顶
		// if(offsetTop>=193 && offsetTop<=237){
		// 	var carTop=(offsetTop-193)/44;
		// 	$('#section9_girl')[0].style.transform='translate3d('+(carTop*700)+'px,0px,0px)';
		// }
		// $('#verticContainer').css('zIndex',100)
		// // Scale2=(offsetTop-108)/280;//
		// $(verticScrollArea2).css('bottom',0)
		// horizontalContainer.style.left=-(screen2W-iW)*Scale2+'px';
	}
}
function fnGun(obj,gunMove){
	if(window.navigator.userAgent.toLowerCase().indexOf('firefox')!=-1){
		obj.addEventListener('DOMMouseScroll',fn);
	}else{
		obj.addEventListener('mousewheel',fn);
	}
	function fn(ev){
		var down=true;
		if(ev.wheelDelta){
			down=ev.wheelDelta>0?true:false;
		}else{
			down=ev.detail>0?false:true;
		}
		// console.log(down)
		typeof gunMove=='function' && gunMove(down);
		ev.preventDefault();
	}
}



})

